<?php get_header(); ?> 
<h1>La page que vous demandez n'existe pas</h1>
<?php get_footer(); ?>