# Exe - 4
## thème Wordpress
### Contient plusieurs commits

Lien (https://github.com/sadektouati/2022-31w-TP2/tree/tp2)

> Le thème conient 8 fichiers et le readme file:
  index.php
  404.php
  category-cours.php
  style.css
  functions.php
  header.php
  footer.php
  readme.md

Pour plus d'information sur la conception de thème
[WP developper guide](https://developper.wordpress.org/theme)
