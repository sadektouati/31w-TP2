# TP - 1
## thème et plugin  Wordpress
### Contient plusieurs commits

Lien (https://github.com/sadektouati/31w/tree/tp1)

> Le thème conient 5 fichiers et le readme file:
index.php
style.css
functions.php
header.php
footer.php
readme.md

Pour plus d'information sur la conception de thème
[WP developper guide](https://developper.wordpress.org/theme)

C'est un travail original