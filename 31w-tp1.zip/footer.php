<footer class="site__footer">
    <h2>Touati Saddek</h2>
    <span>
    theme pour TP
    </span>
</footer>

<?php wp_footer(); ?>

</section> <!-- fin .site -->

</body>

</html>